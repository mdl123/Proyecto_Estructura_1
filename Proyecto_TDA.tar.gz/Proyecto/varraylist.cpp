#include "object.h"
#include "tdalist.h"
#include "varraylist.h"
#include "integer.h"
// Para tener la definición del NULL sin declarar más identificadores
// innecesarios
#include <stddef.h>

//constructor por defecto
VArrayList::VArrayList(){
  capacity=0;
  data= new Object*[0];
}
//constructor que recibe un tamano inicial y la variable incremento sera inicializada en 1 para incrementar mas adelante
VArrayList::VArrayList(unsigned int tam){
  capacity=tam;
  incremento = 1;
  data= new Object*[tam];
}
//constructor que recibe un tamano inicial y un segundo numero que indica en cuanto incrementara el tamano mas adelante
VArrayList::VArrayList(unsigned int tam, unsigned int incre){
  capacity=tam;
  incremento = incre;
  data= new Object*[tam];
}

//constructor de copia recibe un varraylist por parametro e inicializa la variable incremento en 1;
VArrayList::VArrayList(Object** data2){
  data = data2;
  incremento=1;
}
//destructor de varraylist
VArrayList::~VArrayList(){
    if (data)
    data=NULL;
     delete data;
}
/*Fucion de insertar en el arreglo de punteros un elemento hay 2 posibilidades:
(A)El arreglo esta vacio, insertar en la posicion 0.
(B)El arreglo no esta vacio, insertar en posicion mayor o igual que 0
*/
bool VArrayList::insert(Object* data2, int pos){
  if(!(pos>=0) && (pos<size)){
	return false;
  }if(size==capacity){//incrementa la capaidad del arreglo
       Object** temporal= new Object*[size+incremento];
       for(int i=0;i<size;i++)
       temporal[i]=data[i];
       delete data;
       data = temporal;
       capacity+=incremento;
  }if(size==0){
	data[0]=data2;
  }else{
    for(int i=size-1;i>=pos;i--){
	data[i+1]=data[i];
    }
    data[pos]=data2;
  }
  size++;
  
  return true;
}
// Consigue el elemento index de la lista, si index es una posición válida
Object* VArrayList::get(unsigned pos)const{
  if(!(pos>=0) && (pos<size))
   	return NULL;
  return data[pos];

}
/*
* Borra un elemento del arreglo dada la posición del mismo. Se consideran
* dos casos:
* (A) El Elemento es el ultimo
* (B) El Elemento es el primero o esta en medio
*/
Object* VArrayList::remove(unsigned pos){
  Object* tmp =NULL;
  if(!(pos>=0) && (pos<size))
	return tmp;
  tmp= data[pos];//Guarda el objeto en el para retornalo
  if(pos==size-1){
       data[pos]=NULL;
  }else{
	for(int i=pos;i<size-1;i++){
	  data[i]=data[i+1];
	}
  data[size-1]=NULL;
  }
  size--;
  return tmp;

}
// Retorna el primer elemento de arreglo, si es que hay alguno
Object* VArrayList::first()const{
  if(size>0)
    return data[0];
  
  return NULL;
}
// Retorna el último elemento del arreglo, si es que hay alguno
Object* VArrayList::last()const{
  if(size>0)
    return data[size-1];
 
  return NULL;
}

//Búsqueda del índice (posición) de un objeto
int VArrayList::indexOf(Object* data2)const{
  Integer* temp=NULL;
  for(int i=0;i<size;i++){
    temp= dynamic_cast<Integer*>(data[i]);
    if(temp->toString()==(dynamic_cast<Integer*>(data2)->toString()))
	return i;
  }

  return -1;
}
// Elimina todos los elementos del arreglo, coloca size en cero.
void VArrayList::clear(){
  if(data){
    data=NULL;
    size=0;
  }
}
// Imprime cada uno de los elementos que hay en el arreglo, llamando al metodo print de cada elemento
void VArrayList::print()const{
  for(int i=0;i<size;i++)
	data[i]->print();
}

bool VArrayList::isEmpty()const{
  if(size==0)
	return true;
  return false;
}

// Retorna si el arreglo esta lleno, siempre incrementa y retorna false siempre.
bool VArrayList::isFull()const{
   if(size==capacity)
	return true;
   return false;
}

