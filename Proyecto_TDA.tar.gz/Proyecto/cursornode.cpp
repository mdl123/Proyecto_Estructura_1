#include "object.h"
#include"cursornode.h"
#include <iostream>

//Constructor por defecto de la clase cursornode
CursorNode::CursorNode(){
next = prev = -1;
data = NULL;
}

CursorNode::CursorNode(Object* data){
this->data=data;
next=-1;
prev=-1;
}//fin del constructor 


CursorNode::~CursorNode(){


}

// Impresión del Nodo, sólo manda a imprimir el contenido de la data.
void CursorNode::print()const{
    data->print();
}

// Método Accesor de Data
Object* CursorNode::getData()const{
return data;
}//fin del metodo getData

// Método Mutador de Data
void CursorNode::setData(Object* data){
this->data = data;
}

// Método Mutador de Next
void CursorNode::setNext(int x){
next=x;
}//fin del metodo set next

// Método Mutador de Prev
void CursorNode::setPrev(int x){
prev=x;
}//fin del metodo set prev


// Método Accesor de Next
int CursorNode::getNext(){
return next;
}//fin del metodo get next


// Método Accesor de Prev
int CursorNode::getPrev(){
return prev;
}//fin del metodo get prev

