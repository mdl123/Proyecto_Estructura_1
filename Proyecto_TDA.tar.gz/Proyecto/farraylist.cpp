#include "object.h"
#include "tdalist.h"
#include "farraylist.h"
#include "integer.h"
// Para tener la definición del NULL sin declarar más identificadores
// innecesarios
#include <stddef.h>

//constructor por defecto
FArrayList::FArrayList(){
  capacity=0;
  data= new Object*[0];
}
//constructor que recibe la capacidad del arreglo
FArrayList::FArrayList(unsigned int tam){
  capacity=tam;
  data= new Object*[tam];
}
//constructor de copia recibe un farraylist por parametro 
FArrayList::FArrayList(Object** data2){
  data = data2;
}
//destructor de farraylist
FArrayList::~FArrayList(){
    if (data)
     delete data;
}
/*Fucion de insertar en el arreglo de punteros un elemento hay 2 posibilidades:
(A)El arreglo esta vacio, insertar en la posicion 0.
(B)El arreglo no esta vacio, insertar en posicion mayor o igual que 0
*/
bool FArrayList::insert(Object* data2, int pos){
 if(size==capacity){
	return false;
  }if(!(pos>=0) && (pos<size)){
	return false;
  }if(size==0){
	data[0]=data2;
  }else{
    for(int i=size-1;i>=pos;i--){
	data[i+1]=data[i];
    }
        data[pos]=data2;
  }
  size++;
  
  return true;
}
// Consigue el elemento index de la lista, si index es una posición válida
Object* FArrayList::get(unsigned pos)const{
  if(!(pos>=0) && (pos<size))
   	return NULL;
  return data[pos];

}
/*
* Borra un elemento del arreglo dada la posición del mismo. Se consideran
* dos casos:
* (A) El Elemento es el ultimo
* (B) El Elemento es el primero o esta en medio
*/
Object* FArrayList::remove(unsigned pos){
  Object* tmp =NULL;
  if(!(pos>=0) && (pos<size))
	return tmp;
  if(pos==size-1){
        tmp= data[pos];
	data[pos]=NULL;
  }else{
	for(int i=pos;i<size-1;i++){
	  data[i]=data[i+1];
	}
  data[size-1]=NULL;
  }
  size--;
  return tmp;

}
// Retorna el primer elemento de arreglo, si es que hay alguno
Object* FArrayList::first()const{
  if(size>0)
    return data[0];
  
  return NULL;
}
// Retorna el último elemento del arreglo, si es que hay alguno
Object* FArrayList::last()const{
  if(size>0)
    return data[size-1];
 
  return NULL;
}

//Búsqueda del índice (posición) de un objeto
int FArrayList::indexOf(Object* data2)const{
  Integer* temp=NULL;
  for(int i=0;i<size;i++){
    temp= dynamic_cast<Integer*>(data[i]);
    if(temp->toString()==(dynamic_cast<Integer*>(data2)->toString()))
	return i;
  }

  return -1;
}
// Elimina todos los elementos del arreglo, coloca size en cero.
void FArrayList::clear(){
  if(data){
    data=NULL;
    size=0;
  }
}
// Imprime cada uno de los elementos que hay en el arreglo, llamando al metodo print de cada elemento
void FArrayList::print()const{
  for(int i=0;i<size;i++)
	data[i]->print();
}

bool FArrayList::isEmpty()const{
  if(size==0)
	return true;
  return false;
}
// Retorna si el arreglo esta lleno 
bool FArrayList::isFull()const{
   if(size==capacity)
	return true;
   return false;
}

