#include "sdlnode.h"
#include "object.h"
#include <iostream>
using std::cout;
using std::endl;
// Definici�n de los m�todos de la clase SDLNode

// Constructor por Defecto de la Clase. Raramente Usado
SDLNode::SDLNode(){
    next = NULL;
    data = NULL;
}
// Constructor especial de la Clase. Este es el m�s utilizado
SDLNode::SDLNode(Object* aData){
    data = aData;
}
// Constructor especial de la Clase. Raramente Usado
SDLNode::SDLNode(Object* aData, SDLNode* aNext){
    data = aData;
    next = aNext;
}
/*
* Destructor S�per Poderoso de la Clase                                       *
* Este destructor liberar� la memoria que est� ocupando la data a la que      *
* apunte el nodo, de la misma manera, liberar� al nodo siguiente, en el caso  *
* de que hubiera alguno. De esta manera se libera todo lo que tenga el nodo y *
* sus siguientes.                                                             *
* Este destructor es muy �til, sin embargo hay que tener cuidado al querer    *
* s�lo liberar un nodo, pues este deber� estar suelto.                        *
*/
SDLNode::~SDLNode(){
    data=NULL;
    delete data;
    next=NULL;
    delete next;
}
// Impresi�n del Nodo, s�lo manda a imprimir el contenido de la data.
void SDLNode::print()const{
    data->print();
}
// M�todo Accesor de Next
SDLNode* SDLNode::getNext()const{
    return next;
}

// M�todo Mutador de Next
void SDLNode::setNext(SDLNode* aNext){
    next = aNext;
}

// M�todo Accesor de Data
Object* SDLNode::getData()const{
    return data;
}
// M�todo Mutador de Data
void SDLNode::setData(Object* aData){
    data = aData;
}

