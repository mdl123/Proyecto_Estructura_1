#ifndef DLCURSORLIST_H
#define DLCURSORLIST_H
#include "object.h"
#include "tdalist.h"
#include "cursornode.h"


class DLCursorList : public TDAList{
  int nextslot;
  CursorNode* arreglo;
  int head;
  public:
    DLCursorList();
    virtual ~DLCursorList();
    virtual bool insert(Object*, int) ;
    virtual Object* get(unsigned)const ; 
    virtual Object* remove(unsigned) ;
    virtual Object* first()const ;
    virtual Object* last()const ;
    virtual int indexOf(Object*)const;
    virtual void clear();
    virtual void print()const;
    virtual bool isEmpty()const;
    virtual bool isFull()const;
    

};

#endif
