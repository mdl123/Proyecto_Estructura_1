#ifndef SDLNODE_H
#define SDLNODE_H
#include "object.h"
/*
* Esta clase sirve para representar un nodo de listas simples                *
* Simple                                                                     *
* Linked                                                                     *
* List                                                                       *
* Node                                                                       *
* Los miembros de la clase sirven para las dos partes del nodo               *
* [   DATA    ]             Es el puntero al Objeto que contiene los datos   *
* [   NEXT    ]             Es el puntero al nodo siguiente                  *
* ----------------------------------------------------------------------------
* NOTAS:                                                                     *
* En esta implementación se coloca un método print, que lo único que hará    *
* es llamar al método print de data.                                         *
* En esta implementación el destructor de esta clase destruirá cualquier     *
* cosa que esté enlazada con el nodo, de la misma manera que una cadena se   *
* suelta al cortar un eslabón.                                               *
*/

class SDLNode
{
    Object* data;
    SDLNode* next;
  public:
    SDLNode();
    SDLNode(Object*);
    SDLNode(Object*, SDLNode*);
    ~SDLNode();
    void print()const;
    SDLNode* getNext()const;
    void setNext(SDLNode*);
    void setPrev(SDLNode*);
    Object* getData()const;
    void setData(Object*);
};

#endif
