#ifndef VARRAYLIST_H
#define VARRAYLIST_H
#include "object.h"
#include "tdalist.h"


class VArrayList : public TDAList{
  unsigned int capacity;
  unsigned int incremento;
  Object** data;

  public:
    VArrayList();
    VArrayList(unsigned int);
    VArrayList(unsigned int,unsigned int);
    VArrayList(Object**);
    virtual ~VArrayList();
    virtual bool insert(Object*, int) ;
    virtual Object* get(unsigned)const ; 
    virtual Object* remove(unsigned) ;
    virtual Object* first()const ;
    virtual Object* last()const ;
    virtual int indexOf(Object*)const;
    virtual void clear();
    virtual void print()const;
    virtual bool isEmpty()const;
    virtual bool isFull()const;
    int getSize()const;

};

#endif
