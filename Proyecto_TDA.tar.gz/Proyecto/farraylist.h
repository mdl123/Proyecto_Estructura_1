#ifndef FARRAYLIST_H
#define FARRAYLIST_H
#include "object.h"
#include "tdalist.h"


class FArrayList : public TDAList{
  unsigned int capacity;
  Object** data;

  public:
    FArrayList();
    FArrayList(unsigned int);
    FArrayList(Object**);
    virtual ~FArrayList();
    virtual bool insert(Object*, int) ;
    virtual Object* get(unsigned)const ; 
    virtual Object* remove(unsigned) ;
    virtual Object* first()const ;
    virtual Object* last()const ;
    virtual int indexOf(Object*)const;
    virtual void clear();
    virtual void print()const;
    virtual bool isEmpty()const;
    virtual bool isFull()const;
    

};

#endif
