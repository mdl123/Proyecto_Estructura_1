#include "object.h"
#include "tdalist.h"
#include "sdlnode.h"
#include "slinkedlist.h"
#include "integer.h"
// Para tener la definici�n del NULL sin declarar m�s identificadores
// innecesarios
#include <stddef.h>

// Constructor por defecto de SLinkedList
SLinkedList::SLinkedList(){
    head = NULL;
}
// Super Destructor de SLinkedList, n�tese que llamar� al destructor
// de la clase SDLNode, que liberar� todos los nodos siguientes...
SLinkedList::~SLinkedList(){
    if (head)
        delete head;
}
/* 
* Inserci�n en la lista
* En esta operaci�n se consideran cuatro casos generales de inserci�n:
* (A) La Lista est� Vac�a
* (B) Se desea Insertar antes de head (pos = 0)
* (C) Se desea Insertar en Medio de la Lista
* (D) Se desea Insertar al Final (pos = size)
*/


bool SLinkedList::insert(Object* data, int pos) {
    // Si se desa meter en una posici�n inv�lida
    if (pos < 0 || pos > size)
        return false; // Fracaso en esta Operaci�n
    
    // Creaci�n del Nodo que insertaremos en la lista
    SDLNode* neo = new SDLNode(data);
    

    if (!head){ // La lista est� vac�a
        head = neo;
}//fin del if caso 1
    else { // La Lista tiene elementos
        if (pos == 0){ // Desea insertar al principio de la lista
            // Enlace de neo a la lista
            neo->setNext(head);
            head = neo;
        }//fin if caso 2
	else
           if (pos > 0 && pos < size){ // Desea Insertar en medio
            SDLNode* tmp = head;
            // Recorrer hasta la posici�n anterior a la que deseamos insertar
            for (int i=1; i<pos; i++)
               tmp = tmp->getNext();
            // Enlazar el Nodo neo
            neo->setNext(tmp->getNext());
            tmp->setNext(neo);
        }//fin if caso 3
              else { // Desea insertar al final
            SDLNode* tmp = head;
            // Recorrer la Lista hasta el final
            for (int i=1; i<pos; i++)
               tmp = tmp->getNext();
            // Enlazar el Nodo neo
            tmp->setNext(neo);     
        }    
    }
    // Incremento del tama�o
    size++;
    // �xito en la operaci�n
    return true;
}
/*
* B�squeda del �ndice (posici�n) de un objeto
* Para que esta operaci�n tenga �xito es necesario que los objetos que sean
* insertados en la lista tengan bien definido el m�todo equals, pues es este
* m�todo el que determinar� la igualdad de un objeto con otro.
*/
int SLinkedList::indexOf(Object* other)const {
   SDLNode* tmp = head;
   Integer* tmp2=NULL;


    for (int i=0; i < size; i++){
        // Compara cada uno de los elementos con el par�metro
        tmp2=dynamic_cast<Integer*>(tmp->getData());
        if ((tmp2->toString())==dynamic_cast<Integer*>((other))->toString())
                return i;
        tmp = tmp->getNext();
    }    
    // En el caso de no encontrarlo
    return -1;
    
}
// Consigue el elemento index de la lista, si index es una posici�n v�lida
Object* SLinkedList::get(unsigned index)const {
    if (index < 0 || index >= size)
        return NULL;
    SDLNode* tmp = head;
    for (int i=0; i < index; i++)
        tmp = tmp->getNext();
    return tmp->getData();
}
/*
* Borra un elemento de la lista, dada la posici�n del mismo. Se consideran
* tres casos:
* (A) El Elemento es la Cabeza
* (B) El Elemento es el �ltimo
* (C) El Elemento est� en Medio
* Es importante recalcar que para borrar un elemento es necesario primero
* desenlazarlo de la lista y luego liberar su memoria, pues en caso contrario
* liberar�amos todos los elementos siguiente a este elemento.
*/
Object* SLinkedList::remove(unsigned pos) {
    // Si es una posici�n Inv�lida
    Object* temporal = NULL;
    if (pos < 0 || pos >= size)
        return temporal; // Indicar fracaso en la operaci�n
    SDLNode* tmp;
    if (pos == 0){ // Desea Borrar la Cabeza
        // Desenlazar
        temporal = head->getData();
        tmp = head->getNext();
        head->setNext(NULL);
        // Liberar Memoria
        delete head;
        // Actualizar head
        head = tmp;
    }//fin del caso 1
else if (pos == size - 1){ // Desea Borrar el �ltimo
        // Recorrer hasta el final
        tmp = head;
        for (int i=1; i<pos; i++)
           tmp = tmp->getNext();
        //guardar el objeto
        temporal = tmp->getNext()->getData();
        // Desenlazar   
        tmp->setNext(NULL);
        // Liberar Memoria
    }//fin del caso 3
else { // Desea Borrar de enmedio
        // Recorrer hasta el nodo anterior al que se desea borrar
        tmp = head;
        for (int i=1; i<pos; i++)
           tmp = tmp->getNext();
        //guardar el objeto
        temporal = tmp->getNext()->getData();
        // Desenlazar
        SDLNode* toErase = tmp->getNext();
        tmp->setNext(toErase->getNext());
        toErase->setNext(NULL);
        // Liberar Memoria
 
//confirmar
              
    }
    size--; // Disminuir Tama�o
    return temporal; // Indicar �xito
}

// Retorna el siguiente a la posici�n pos
// Implementado de la manera m�s sencilla, pues podr�a haberse usado
// SDLNode*
int SLinkedList::next(int pos) const {
    return pos + 1;
}
// Elimina todos los elementos de la lista, coloca size en cero, y la cabeza
// en NULL, o sea que hace un poco m�s que el destructor.
void SLinkedList::clear() {
    if (head)
        delete head;
    head = NULL;
    size = 0;
}
// Retorna el primer elemento de la lista, si es que hay alguno
Object* SLinkedList::first()const {
    if (head)
        return head->getData();
    return NULL;
}
// Retorna el �ltimo elemento de la lista, si es que hay alguno
Object* SLinkedList::last()const {
    if (!head)
        return NULL;
    SDLNode* tmp = head;
    for (int i=0; i < size-1; i++)
        tmp = tmp->getNext();
    return tmp->getData();
}
// Imprime cada uno de los elementos que hay en la lista, llamando al m�todo
// print de cada nodo.
void SLinkedList::print()const {
    SDLNode* tmp = head;
    for (int i=0; i < size; i++){
        tmp->print();
        tmp = tmp->getNext();
    }    
}
// Retorna si la lista est� llena, como nunca es as�, retorna false siempre.
bool SLinkedList::isFull()const {
    return false;
}

Object* get(int pos){
  SDLNode* tmp= NULL;
   for(int i=1;i<pos;i++){
	tmp->getNext()->getData();

   }//fin del for

return tmp->getData();
}//fin de la funcion get

bool SLinkedList::isEmpty()const {
    return false;
}


