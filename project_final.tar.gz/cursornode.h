#ifndef CURSORNODE_H
#define CURSORNODE_H

#include "object.h"


class CursorNode {

	Object* data;
	int prev;
	int next;
    public:
	CursorNode();
	CursorNode(Object*);
        ~CursorNode();
	void setNext(int);
	void setPrev(int);
	int getNext();
	int getPrev();
        void print()const;
        void setData(Object*);
        Object* getData()const;

};//fin de la clase CursorNode

#endif
