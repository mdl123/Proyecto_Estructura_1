#include "object.h"
#include "tdalist.h"
#include "cursornode.h"
#include "dlcursorlist.h"
#include "integer.h"
#include <iostream>
// Para tener la definición del NULL sin declarar más identificadores
// innecesarios
#include <stddef.h>
using namespace std;
//constructor por defecto
DLCursorList::DLCursorList(){
 arreglo = new CursorNode[40];
 nextslot=0;
 head -1;
}
//Destructor
DLCursorList::~DLCursorList(){

arreglo=NULL;
delete arreglo;
}


/* 
* Inserción en la lista
* En esta operación se consideran tres casos generales de inserción:
* (A) La Lista está Vacía
* (B) Se desea Insertar antes de head (pos = 0) y en medio
* (C) Se desea Insertar al Final (pos = size)
*/
bool DLCursorList::insert(Object* dat , int pos){

if((pos<0 || pos>size))
return false;
 
if(size==0 && pos==0){
head =0;
arreglo[head].setData(dat);
arreglo[head].setNext(-1);
arreglo[head].setPrev(-1);
nextslot=1;
}else if(size>0 && pos>0){
int neo = nextslot;
arreglo[neo].setData(dat);
int temp = head;
for(int i=0;i<pos-1;i++)
temp = arreglo[temp].getNext();
arreglo[neo].setPrev(temp);
arreglo[neo].setNext(arreglo[temp].getNext());
arreglo[temp].setNext(neo);
if(pos<size){
arreglo[arreglo[neo].getNext()].setPrev(neo);
}
nextslot++;
}else if(size>0 && pos==0){
int neo =nextslot;
arreglo[neo].setData(dat);
arreglo[head].setPrev(neo);
arreglo[neo].setNext(head);
arreglo[neo].setPrev(-1);
head = neo;
nextslot++;
}
size++;
return true;

}//fin de la funcion insertar

Object* DLCursorList::remove(unsigned int pos){
if(pos<0||pos>size)
return false;
Object* tmp=arreglo[pos].getData();

if(pos==0 ){
int temp =head;
arreglo[temp].setData(NULL);
head=arreglo[temp].getNext();
arreglo[temp].setPrev(-1);
arreglo[temp].setNext(-1);
}else if(pos>0){
int temp =head;
for(int i=0; i<pos-1;i++)
temp = arreglo[temp].getNext();
arreglo[temp].setData(NULL);
arreglo[arreglo[temp].getPrev()].setNext(arreglo[temp].getNext());
if(pos!=size-1){
arreglo[arreglo[temp].getNext()].setPrev(arreglo[temp].getPrev());
arreglo[temp].setNext(-1);
}
arreglo[temp].setPrev(-1);

}
size--;
return tmp;

}//fin del metodo remove

Object* DLCursorList::get(unsigned int pos)const{
if(pos<0||pos>=size)
return NULL;
int tmp=head;//variable para guardar la posicion del arreglo
for(int i=0;i<pos;i++){
tmp=arreglo[tmp].getNext();
}
return arreglo[tmp].getData();

}//fin del get

int DLCursorList::indexOf(Object* other)const {
  int temp = head;
  Integer* tmp2=NULL;
  for(int i=0;i<size-1;i++){
  tmp2 = dynamic_cast<Integer*>(arreglo[temp].getData());
  Integer* y=dynamic_cast<Integer*>(other);
       if(tmp2->toString()==(y->toString())){
	return i;
	}//fin if
  temp = arreglo[temp].getNext();
  }//fin del for   

  return -1;
}//fin del metodo

// Retorna el primer elemento de la lista, si es que hay alguno
Object* DLCursorList::first()const {

    if(getSize()==0)
    return NULL;
    else
    return arreglo[head].getData();
   
}//fin del metodo

// Retorna el último elemento de la lista, si es que hay alguno
Object* DLCursorList::last()const {
    if(getSize()==0)
    return NULL;
    int temp =head;
    for(int i=0;i<size-1;i++)
      temp=arreglo[temp].getNext();
    return arreglo[temp].getData();
 }//fin del metodo last


// Imprime cada uno de los elementos que hay en el arreglo, llamando al método
// print de cada nodo.
void DLCursorList::print()const {
   if(!getSize()>0){
   }else{
   int vueltas=1;
   while(vueltas!=-2){
   for(int i=0;i<getSize();i++){
    if(arreglo[i].getNext()==vueltas){
    arreglo[i].getData()->print();
    if(vueltas==-1)
    vueltas=-2;
    if(vueltas<getSize()-1)
    vueltas++;
    else
    vueltas=-1;
    i=getSize();
   }
   }
   }
   }
    
}
// Elimina todos los elementos de la lista, coloca size en cero
void DLCursorList::clear() {
    if(arreglo)
 arreglo = new CursorNode[20];
    size = 0;
}
// Retorna si la lista está llena, como nunca es así, retorna false siempre.
bool DLCursorList::isFull()const {
    return false;
}

bool DLCursorList::isEmpty()const {
    return false;
}

